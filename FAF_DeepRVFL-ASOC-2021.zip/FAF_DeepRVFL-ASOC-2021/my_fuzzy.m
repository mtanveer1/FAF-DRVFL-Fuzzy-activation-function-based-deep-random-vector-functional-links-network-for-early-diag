function Fuzzy_MatData =my_fuzzy(X)

%%%%    Authors:   Rahul Sharma^a, Tripti Goel^a, M Tanveer^b
    %%%%    a: Biomedical Imaging Lab, National Institute of Technology Silchar, Assam, 788010, India
    %%%%    b: Department of Mathematics, Indian Institute of Technology Indore, Simrol, Indore, 453552, India
    %%%%    EMAIL:      rahul_rs@ece.nits.ac.in (R. Sharma),triptigoel@ece.nits.ac.in (T. Goel), mtanveer@iiti.ac.in (M. Tanveer)
    %%%%    DATE OF PUBLICATION:       8 April 2021 
    %%%% Please cite as: Sharma, R., Goel, T., Tanveer, M., Dwivedi, S., & Murugan, R. (2021). FAF-DRVFL: Fuzzy activation function based deep random vector functional links network for early diagnosis of Alzheimer disease. Applied Soft Computing, 106, 107371.

fprintf('Finding mean, min and max matrices for the  data\n'); 

rr = (mean(X'))';
aa = (min(X'))';
bb = (max(X'))';

no_feature = size(X,1); 
Fuzzy_MatData = zeros(size(X));

fprintf('Finding the membership grade for given data set\n'); 
for i = 1:no_feature
%     Fuzzy_MatData(i, :) = pimf(X(i,:), [aa(i,1),rr(i,1),rr(i,1),bb(i,1)]);
%     Fuzzy_MatData(i, :) = trapmf(X(i,:), [aa(i,1),rr(i,1), rr(i,1),bb(i,1)]);
    Fuzzy_MatData(i, :) = smf(X(i,:), [aa(i,1), bb(i,1)]);
      
end