% FAF-DRVFL: Fuzzy activation function based deep random vector functional links network for early diagnosis of Alzheimer disease
% Input: File Path of 2D MRI slices for 2 classes
% Output: Test Accuracy,Sensitivity, specificity, precision, recall, F1 Score and Confusion Matrix 
    %%%%    Authors:   Rahul Sharma^a, Tripti Goel^a, M Tanveer^b
    %%%%    a: Biomedical Imaging Lab, National Institute of Technology Silchar, Assam, 788010, India
    %%%%    b: Department of Mathematics, Indian Institute of Technology Indore, Simrol, Indore, 453552, India
    %%%%    EMAIL:      rahul_rs@ece.nits.ac.in (R. Sharma),triptigoel@ece.nits.ac.in (T. Goel), mtanveer@iiti.ac.in (M. Tanveer)
    %%%%    DATE OF PUBLICATION:       8 April 2021 
    %%%% Please cite as: Sharma, R., Goel, T., Tanveer, M., Dwivedi, S., & Murugan, R. (2021). FAF-DRVFL: Fuzzy activation function based deep random vector functional links network for early diagnosis of Alzheimer disease. Applied Soft Computing, 106, 107371.

%% Load Dataset
  imds = imageDatastore(File_Path,'IncludeSubfolders', true,...
       'LabelSource','foldernames');
   
%% Split data into training and testing
   [traindata,testdata]=splitEachLabel(imds, 0.7,'randomize');
    disp(traindata);
    
%%  Load ResNet50    
     net = resnet50;
     siz= net.Layers(1).InputSize;
    
% % Data Augmentation
    augmentedTrainingSet = augmentedImageDatastore(siz(1:3),traindata,'ColorPreprocessing', 'gray2rgb');
    augmentedTestSet = augmentedImageDatastore(siz(1:3),testdata,'ColorPreprocessing', 'gray2rgb');

   
    lgraph=layerGraph(net);

    newLearnableLayer = fullyConnectedLayer(2, ...
        'Name','new_fc', ...
        'WeightLearnRateFactor',10, ...
        'BiasLearnRateFactor',10);
    
    % Replacing the last layers with new layers
    lgraph = replaceLayer(lgraph,'fc1000',newLearnableLayer);
    newsoftmaxLayer = softmaxLayer('Name','new_softmax');
    lgraph = replaceLayer(lgraph,'fc1000_softmax',newsoftmaxLayer);
    newClassLayer = classificationLayer('Name','new_classoutput');
    lgraph = replaceLayer(lgraph,'ClassificationLayer_fc1000',newClassLayer);

  %% Training Options
    miniBatchSize = 20;
    learningRate = 4e-03;
    maxEpochs=5;
    optimizer='sgdm';

    options=trainingOptions(optimizer,...
        "MiniBatchSize",miniBatchSize,...
        "InitialLearnRate",learningRate,...
        'MaxEpochs',maxEpochs,...
        "L2Regularization",1e-05,...
        "Shuffle",'every-epoch',...
        "Verbose",false,...
        "Plots","training-progress");
 %% Train Network

    [trainedNet,info]=trainNetwork(augmentedTrainingSet,lgraph,options);

 %% Feature Extraction
    featureLayer = 'new_fc';
        trainingFeatures = activations(trainedNet, augmentedTrainingSet, featureLayer, ...
            'MiniBatchSize', 64, 'OutputAs', 'columns');

    trainingFeatures = double(trainingFeatures);
    testLabels = testdata.Labels;
    % Get training labels from the trainingSet
    trainingLabels = traindata.Labels;
    
    testLabels = double(testLabels);
    trainingLabels = double(trainingLabels);

    
    testFeatures = activations(trainedNet, augmentedTestSet, featureLayer, ...
        'MiniBatchSize', 64, 'OutputAs', 'columns');
    
    testFeatures = double(testFeatures);
    fprintf('Creating the target matrix for tarining of ANN\n');

    option.N = 150000;
    option.ActivationFunction = 'my_fuzzy';
    
  %% Fuzzy RVFL for Classification  
    [train_accuracy,test_accuracy]=RVFL_train_val(trainingFeatures',trainingLabels,testFeatures',testLabels,option)
%     timetaken = toc;
      
    load Yt_temp
    load testY_temp
    load testY
  
  %% Performance Calculation 
    confMat = confusionmat(testLabels, Yt_temp);
    confMat1 = bsxfun(@rdivide,confMat,sum(confMat,2));
    confusionchart(testLabels, Yt_temp);
    EVAL = Evaluate(testLabels, Yt_temp);
   


